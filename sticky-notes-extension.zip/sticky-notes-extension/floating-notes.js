/*
 * Sticky Notes Widget - Complete Functionality
 * Created by Ashish Kumar
 * GitHub: https://github.com/Ashish1731
 */

(function () {
    'use strict';

    var notes = [];
    var isMinimized = false;
    var isVisible = true;
    var isClosed = false;
    var isLocked = false;
    var currentOpacity = 0.9;
    var hideHintTimeout = null;
    var widgetElement = null;
    var pinIcon = null;
    var lockButton = null;
    var draggedItem = null;
    var isDraggingWidget = false;
    var hasDragged = false;

    // ===== STORAGE HELPERS =====
    function isStorageAvailable() {
        try {
            return typeof chrome !== 'undefined' &&
                chrome.storage &&
                chrome.storage.local;
        } catch (e) {
            return false;
        }
    }

    function loadFromStorage(key, callback) {
        if (!isStorageAvailable()) {
            callback(null);
            return;
        }
        try {
            chrome.storage.local.get([key], function (result) {
                if (chrome.runtime.lastError) {
                    callback(null);
                    return;
                }
                callback(result[key]);
            });
        } catch (e) {
            callback(null);
        }
    }

    function saveToStorage(key, value) {
        if (!isStorageAvailable()) {
            return;
        }
        try {
            var data = {};
            data[key] = value;
            chrome.storage.local.set(data, function () {
                if (chrome.runtime.lastError) {
                    // Silently fail
                }
            });
        } catch (e) {
            // Silently fail
        }
    }

    function removeFromStorage(keys, callback) {
        if (!isStorageAvailable()) {
            if (callback) callback();
            return;
        }
        try {
            chrome.storage.local.remove(keys, function () {
                if (chrome.runtime.lastError) {
                    // Silently fail
                }
                if (callback) callback();
            });
        } catch (e) {
            if (callback) callback();
        }
    }

    // ===== SAFE MESSAGE SENDER =====
    function sendMessageToBackground(message, callback) {
        try {
            if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id) {
                chrome.runtime.sendMessage(message, function (response) {
                    if (chrome.runtime.lastError) {
                        if (callback) callback(null);
                        return;
                    }
                    if (callback) callback(response);
                });
            } else {
                if (callback) callback(null);
            }
        } catch (e) {
            if (callback) callback(null);
        }
    }

    // ===== NOTES =====
    function loadNotes() {
        loadFromStorage('notes', function (data) {
            notes = data || [];
            sortNotes();
            renderNotes();
        });
    }

    function saveNotes() {
        saveToStorage('notes', notes);
        updateBadge();
    }

    function sortNotes() {
        var priorityOrder = { 'high': 0, 'medium': 1, 'low': 2 };
        notes.sort(function (a, b) {
            var pa = priorityOrder[a.priority || 'medium'] || 1;
            var pb = priorityOrder[b.priority || 'medium'] || 1;
            if (pa !== pb) return pa - pb;
            if (a.done !== b.done) return a.done ? 1 : -1;
            return (b.createdAt || 0) - (a.createdAt || 0);
        });
    }

    function updateBadge() {
        var pending = notes.filter(function (n) { return !n.done; }).length;
        var badge = document.querySelector('.task-badge');
        var pinBadge = document.querySelector('.pin-badge');
        if (badge) badge.textContent = pending > 0 ? pending + ' tasks' : '0 tasks';
        if (pinBadge) {
            pinBadge.textContent = pending > 0 ? pending : '';
            pinBadge.style.display = pending > 0 ? 'flex' : 'none';
        }
    }

    function escapeHtml(text) {
        var div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    function getPriorityColor(priority) {
        var colors = { 'high': '#ff4757', 'medium': '#ffa502', 'low': '#2ed573' };
        return colors[priority] || '#ffa502';
    }

    function getPriorityLabel(priority) {
        var labels = { 'high': '🔴 High', 'medium': '🟡 Medium', 'low': '🟢 Low' };
        return labels[priority] || '🟡 Medium';
    }

    function renderNotes() {
        var list = document.getElementById('floatingList');
        if (!list) return;

        if (notes.length === 0) {
            list.innerHTML = '<div class="floating-empty"><span>📋</span><p>No tasks yet</p></div>';
            updateBadge();
            return;
        }

        var html = '';
        for (var i = 0; i < notes.length; i++) {
            var note = notes[i];
            var doneClass = note.done ? 'done' : '';
            var textClass = note.done ? 'done' : '';
            var priorityColor = getPriorityColor(note.priority || 'medium');
            var priorityLabel = getPriorityLabel(note.priority || 'medium');

            html += '<div class="floating-item" data-index="' + i + '" draggable="true">';
            html += '<div class="drag-handle" title="Drag to reorder">⠿</div>';
            html += '<div class="checkbox ' + doneClass + '" data-index="' + i + '"></div>';
            html += '<span class="text ' + textClass + '">' + escapeHtml(note.text) + '</span>';
            html += '<div class="priority-badge" style="background:' + priorityColor + ';color:white;" data-index="' + i + '">';
            html += priorityLabel;
            html += '</div>';
            html += '<button class="delete-btn" data-index="' + i + '">✕</button>';
            html += '</div>';
        }
        list.innerHTML = html;

        var checkboxes = list.querySelectorAll('.checkbox');
        for (var j = 0; j < checkboxes.length; j++) {
            checkboxes[j].addEventListener('click', toggleNote);
        }

        var deleteBtns = list.querySelectorAll('.delete-btn');
        for (var k = 0; k < deleteBtns.length; k++) {
            deleteBtns[k].addEventListener('click', deleteNote);
        }

        var priorityBadges = list.querySelectorAll('.priority-badge');
        for (var l = 0; l < priorityBadges.length; l++) {
            priorityBadges[l].addEventListener('click', function (e) {
                e.stopPropagation();
                var index = parseInt(this.dataset.index);
                cyclePriority(index);
            });
        }

        setupDragAndDrop(list);
        updateBadge();
    }

    // ===== DRAG AND DROP =====
    function setupDragAndDrop(list) {
        var items = list.querySelectorAll('.floating-item');

        items.forEach(function (item) {
            item.addEventListener('dragstart', function (e) {
                if (isLocked) {
                    e.preventDefault();
                    return;
                }
                draggedItem = this;
                this.style.opacity = '0.4';
                e.dataTransfer.effectAllowed = 'move';
                e.dataTransfer.setData('text/plain', this.dataset.index);
            });

            item.addEventListener('dragend', function (e) {
                this.style.opacity = '1';
                document.querySelectorAll('.drag-over').forEach(function (el) {
                    el.classList.remove('drag-over');
                });
            });

            item.addEventListener('dragover', function (e) {
                e.preventDefault();
                if (isLocked) return;
                this.classList.add('drag-over');
            });

            item.addEventListener('dragleave', function (e) {
                this.classList.remove('drag-over');
            });

            item.addEventListener('drop', function (e) {
                e.preventDefault();
                if (isLocked) return;
                this.classList.remove('drag-over');

                var fromIndex = parseInt(draggedItem.dataset.index);
                var toIndex = parseInt(this.dataset.index);

                if (fromIndex !== toIndex) {
                    var movedNote = notes.splice(fromIndex, 1)[0];
                    notes.splice(toIndex, 0, movedNote);
                    saveNotes();
                    renderNotes();
                    showToast('✅ Task reordered!');
                }
            });
        });
    }

    // ===== PRIORITY =====
    function cyclePriority(index) {
        if (isLocked) return;
        var priorities = ['low', 'medium', 'high'];
        var current = notes[index].priority || 'medium';
        var currentIndex = priorities.indexOf(current);
        var nextIndex = (currentIndex + 1) % priorities.length;
        notes[index].priority = priorities[nextIndex];
        sortNotes();
        saveNotes();
        renderNotes();
        showToast('🔄 Priority: ' + priorities[nextIndex].toUpperCase());
    }

    // ===== ACTIONS =====
    function addNote() {
        if (isLocked) {
            showToast('🔒 Widget is locked!');
            return;
        }
        var input = document.getElementById('noteInput');
        if (!input) {
            console.error('Note input not found');
            return;
        }
        var text = input.value.trim();
        if (!text) {
            input.style.borderColor = '#d34a4a';
            setTimeout(function () { input.style.borderColor = ''; }, 1500);
            return;
        }

        var prioritySelect = document.getElementById('prioritySelect');
        var priority = prioritySelect ? prioritySelect.value : 'medium';

        notes.unshift({
            text: text,
            done: false,
            priority: priority,
            createdAt: Date.now()
        });
        sortNotes();
        input.value = '';
        if (prioritySelect) prioritySelect.value = 'medium';
        saveNotes();
        renderNotes();
        input.focus();
        showToast('✅ Task added: ' + text);
    }

    function toggleNote(e) {
        if (isLocked) {
            showToast('🔒 Widget is locked!');
            return;
        }
        var index = parseInt(e.currentTarget.dataset.index);
        notes[index].done = !notes[index].done;
        sortNotes();
        saveNotes();
        renderNotes();
    }

    function deleteNote(e) {
        if (isLocked) {
            showToast('🔒 Widget is locked!');
            return;
        }
        var index = parseInt(e.currentTarget.dataset.index);
        notes.splice(index, 1);
        saveNotes();
        renderNotes();
    }

    function clearAll() {
        if (isLocked) {
            showToast('🔒 Widget is locked!');
            return;
        }
        if (notes.length === 0) return;
        if (confirm('Delete all tasks?')) {
            notes = [];
            saveNotes();
            renderNotes();
        }
    }

    // ===== OPACITY =====
    function updateOpacity(value) {
        if (!widgetElement) return;
        currentOpacity = value / 100;
        widgetElement.style.opacity = currentOpacity;
        var display = document.getElementById('opacityValue');
        if (display) display.textContent = Math.round(value) + '%';
        saveToStorage('widgetOpacity', currentOpacity);
    }

    // ===== TOAST NOTIFICATION =====
    function showToast(message) {
        var toast = document.getElementById('floatingToast');
        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'floatingToast';
            toast.style.cssText = 'position:fixed;bottom:80px;right:20px;background:rgba(26,47,78,0.95);color:white;padding:12px 20px;border-radius:10px;font-family:-apple-system,sans-serif;font-size:14px;z-index:999997;box-shadow:0 8px 24px rgba(0,0,0,0.3);max-width:300px;transition:opacity 0.3s;opacity:0;pointer-events:none;';
            document.body.appendChild(toast);
        }
        toast.textContent = message;
        toast.style.opacity = '1';
        clearTimeout(hideHintTimeout);
        hideHintTimeout = setTimeout(function () {
            toast.style.opacity = '0';
        }, 2500);
    }

    // ===== HELP TOOLTIP =====
    function showHelpTooltip() {
        var existing = document.getElementById('helpTooltip');
        if (existing) {
            existing.remove();
            return;
        }

        var tooltip = document.createElement('div');
        tooltip.id = 'helpTooltip';
        tooltip.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            padding: 24px 30px;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            z-index: 9999999;
            max-width: 380px;
            width: 90%;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        `;

        tooltip.innerHTML = `
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
                <h3 style="margin:0;color:#1a2a4a;">⌨️ Keyboard Shortcuts</h3>
                <button id="closeHelpBtn" style="background:none;border:none;font-size:20px;cursor:pointer;color:#999;">✕</button>
            </div>
            <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #f0f4f8;font-size:13px;">
                <span>Lock / Unlock</span>
                <code style="background:#eef3f9;padding:2px 10px;border-radius:4px;font-size:12px;">Ctrl+Shift+L</code>
            </div>
            <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #f0f4f8;font-size:13px;">
                <span>Hide / Show</span>
                <code style="background:#eef3f9;padding:2px 10px;border-radius:4px;font-size:12px;">Ctrl+Shift+N</code>
            </div>
            <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #f0f4f8;font-size:13px;">
                <span>Minimize to Pin</span>
                <code style="background:#eef3f9;padding:2px 10px;border-radius:4px;font-size:12px;">Ctrl+Shift+M</code>
            </div>
            <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #f0f4f8;font-size:13px;">
                <span>Reset All States</span>
                <code style="background:#eef3f9;padding:2px 10px;border-radius:4px;font-size:12px;">Ctrl+Shift+R</code>
            </div>
            <div style="display:flex;justify-content:space-between;padding:6px 0;font-size:13px;">
                <span>Add Task</span>
                <code style="background:#eef3f9;padding:2px 10px;border-radius:4px;font-size:12px;">Enter</code>
            </div>
            <div style="margin-top:16px;padding-top:12px;border-top:1px solid #eee;text-align:center;font-size:12px;color:#888;">
                Click ❓ again to close
            </div>
        `;

        document.body.appendChild(tooltip);

        document.getElementById('closeHelpBtn').addEventListener('click', function () {
            tooltip.remove();
        });

        document.addEventListener('keydown', function closeHelp(e) {
            if (e.key === 'Escape') {
                tooltip.remove();
                document.removeEventListener('keydown', closeHelp);
            }
        });
    }

    // ===== CONTROLS =====
    function toggleMinimize() {
        if (!widgetElement || !pinIcon) return;
        isMinimized = !isMinimized;

        if (isMinimized) {
            var rect = widgetElement.getBoundingClientRect();
            var posX = rect.left;
            var posY = rect.top;

            widgetElement.classList.add('minimized');
            widgetElement.style.display = 'none';

            pinIcon.style.left = posX + 'px';
            pinIcon.style.top = posY + 'px';
            pinIcon.style.right = 'auto';
            pinIcon.style.display = 'flex';

            saveToStorage('widgetMinimized', true);
            saveToStorage('widgetPosition', { x: posX, y: posY });
            showToast('📌 Widget minimized to pin');
        } else {
            var pinRect = pinIcon.getBoundingClientRect();
            var posX = pinRect.left;
            var posY = pinRect.top;

            pinIcon.style.display = 'none';
            widgetElement.classList.remove('minimized');
            widgetElement.style.display = 'flex';

            widgetElement.style.left = posX + 'px';
            widgetElement.style.top = posY + 'px';
            widgetElement.style.right = 'auto';

            saveToStorage('widgetMinimized', false);
            saveToStorage('widgetPosition', { x: posX, y: posY });
            showToast('📌 Widget restored');
        }
    }

    function closeWidget() {
        if (!widgetElement) return;
        isClosed = true;
        isVisible = false;
        widgetElement.style.display = 'none';
        if (pinIcon) pinIcon.style.display = 'none';
        saveToStorage('widgetVisible', false);
        saveToStorage('widgetClosed', true);
        showToast('📌 Widget closed. Click extension icon to reopen');
    }

    function showWidget() {
        if (!widgetElement) return;
        if (isMinimized) {
            toggleMinimize();
            return;
        }
        isClosed = false;
        isVisible = true;
        widgetElement.style.display = 'flex';
        if (pinIcon) pinIcon.style.display = 'none';
        saveToStorage('widgetVisible', true);
        saveToStorage('widgetClosed', false);
        showToast('📌 Widget opened');
    }

    function setLockState(locked) {
        if (!widgetElement) return;
        if (!lockButton) lockButton = document.getElementById('lockBtn');
        if (!lockButton) return;

        isLocked = locked;
        widgetElement.classList.toggle('locked', locked);
        lockButton.classList.toggle('locked', locked);
        lockButton.textContent = locked ? '🔒' : '🔓';
        lockButton.title = locked ? 'Unlock (Ctrl+Shift+L)' : 'Lock (Ctrl+Shift+L)';
        saveToStorage('widgetLocked', locked);

        if (locked) {
            showToast('🔒 Widget locked');
        } else {
            showToast('🔓 Widget unlocked');
        }
    }

    function toggleLock() {
        if (!isLocked) {
            showLockConfirmation();
        } else {
            setLockState(false);
        }
    }

    function showLockConfirmation() {
        var existing = document.getElementById('lockConfirmation');
        if (existing) existing.remove();

        var overlay = document.createElement('div');
        overlay.id = 'lockConfirmation';
        overlay.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.5);z-index:9999999;display:flex;align-items:center;justify-content:center;font-family:-apple-system,sans-serif;';

        var popup = document.createElement('div');
        popup.style.cssText = 'background:white;padding:30px;border-radius:16px;max-width:380px;width:90%;box-shadow:0 20px 60px rgba(0,0,0,0.3);text-align:center;';

        popup.innerHTML = `
            <div style="font-size:48px;margin-bottom:12px;">🔒</div>
            <h2 style="color:#1a2a4a;margin-bottom:8px;">Lock Widget</h2>
            <p style="color:#666;font-size:14px;line-height:1.6;margin-bottom:16px;">
                This will prevent any interaction with the widget.<br>
                <strong style="color:#1a2f4e;">Unlock with:</strong>
            </p>
            <div style="background:#eef3f9;padding:10px;border-radius:8px;margin-bottom:20px;font-family:monospace;font-size:16px;color:#1a2f4e;">
                Ctrl + Shift + L
            </div>
            <div style="display:flex;gap:10px;justify-content:center;">
                <button id="lockConfirm" style="padding:10px 30px;background:#1a2f4e;color:white;border:none;border-radius:8px;font-weight:600;cursor:pointer;font-size:14px;">Lock</button>
                <button id="lockCancel" style="padding:10px 20px;background:#eef3f9;color:#666;border:none;border-radius:8px;font-weight:600;cursor:pointer;font-size:14px;">Cancel</button>
            </div>
        `;

        overlay.appendChild(popup);
        document.body.appendChild(overlay);

        document.getElementById('lockConfirm').addEventListener('click', function () {
            setLockState(true);
            overlay.remove();
        });

        document.getElementById('lockCancel').addEventListener('click', function () {
            overlay.remove();
        });

        overlay.addEventListener('click', function (e) {
            if (e.target === overlay) overlay.remove();
        });
    }

    // ===== DRAG =====
    function makeDraggable(element, isPin) {
        if (!element) return;

        var isDragging = false;
        var offsetX, offsetY;
        var startX, startY;

        var dragHandle = element.querySelector('.drag-widget-handle');
        var targetElement = dragHandle || element;

        targetElement.addEventListener('mousedown', function (e) {
            if (isLocked) return;
            if (!isPin && e.target.closest('.controls')) return;
            if (!isPin && e.target.closest('.floating-add')) return;
            if (!isPin && e.target.closest('.floating-list')) return;
            if (!isPin && e.target.closest('.floating-footer')) return;
            if (!isPin && e.target.closest('.opacity-controls')) return;

            isDragging = true;
            hasDragged = false;
            isDraggingWidget = true;
            var rect = element.getBoundingClientRect();
            offsetX = e.clientX - rect.left;
            offsetY = e.clientY - rect.top;
            startX = e.clientX;
            startY = e.clientY;
            element.style.cursor = 'grabbing';
            e.preventDefault();
        });

        document.addEventListener('mousemove', function (e) {
            if (!isDragging) return;

            if (!hasDragged) {
                var dx = e.clientX - startX;
                var dy = e.clientY - startY;
                if (Math.abs(dx) > 5 || Math.abs(dy) > 5) {
                    hasDragged = true;
                }
            }

            var x = e.clientX - offsetX;
            var y = e.clientY - offsetY;
            var rect = element.getBoundingClientRect();
            x = Math.max(0, Math.min(window.innerWidth - rect.width, x));
            y = Math.max(0, Math.min(window.innerHeight - rect.height, y));
            element.style.left = x + 'px';
            element.style.right = 'auto';
            element.style.top = y + 'px';

            if (isPin && isMinimized) {
                saveToStorage('widgetPosition', { x: x, y: y });
            }
        });

        document.addEventListener('mouseup', function () {
            if (isDragging) {
                isDragging = false;
                isDraggingWidget = false;
                element.style.cursor = '';
                var rect = element.getBoundingClientRect();
                saveToStorage('widgetPosition', { x: rect.left, y: rect.top });
            }
        });
    }

    // ===== RESET ALL STATES =====
    function resetAllStates() {
        isLocked = false;
        isMinimized = false;
        isVisible = true;
        isClosed = false;

        if (widgetElement) {
            widgetElement.classList.remove('locked', 'minimized');
            widgetElement.style.display = 'flex';
            widgetElement.style.opacity = currentOpacity;
            widgetElement.style.left = '80px';
            widgetElement.style.top = '80px';
            widgetElement.style.right = 'auto';
        }

        if (pinIcon) {
            pinIcon.style.display = 'none';
        }

        if (lockButton) {
            lockButton.classList.remove('locked');
            lockButton.textContent = '🔓';
            lockButton.title = 'Lock (Ctrl+Shift+L)';
        }

        removeFromStorage(['widgetLocked', 'widgetMinimized', 'widgetVisible', 'widgetClosed', 'widgetPosition'], function () {
            showToast('🔄 All states reset');
        });
    }

    // ===== CREATE WIDGET =====
    function createWidget() {
        // Prevent duplicate widget
        if (document.getElementById('floatingWidget')) {
            return;
        }

        // Check if widget should be visible
        loadFromStorage('widgetClosed', function (closed) {
            if (closed === true) {
                return;
            }

            // Main Widget
            widgetElement = document.createElement('div');
            widgetElement.id = 'floatingWidget';
            widgetElement.className = 'floating-notes-widget';

            widgetElement.innerHTML = `
                <div class="floating-header">
                    <div class="title">
                        <span class="drag-widget-handle" title="Drag to move">⠿</span>
                        📌 Sticky Notes
                    </div>
                    <div class="controls">
                        <span class="task-badge">0 tasks</span>
                        <button class="help-btn" id="helpBtn" title="Show shortcuts">❓</button>
                        <button class="lock-btn" id="lockBtn" title="Lock (Ctrl+Shift+L)">🔓</button>
                        <button id="minimizeBtn" title="Minimize to pin (Ctrl+Shift+M)">−</button>
                        <button id="closeBtn" title="Close widget (Ctrl+Shift+N)">✕</button>
                    </div>
                </div>
                <div class="opacity-controls">
                    <label>🔆 <span id="opacityValue">90%</span></label>
                    <input type="range" id="opacitySlider" min="10" max="100" value="90" />
                </div>
                <div class="floating-body">
                    <div class="floating-add">
                        <input type="text" id="noteInput" placeholder="Add a task..." />
                        <select id="prioritySelect">
                            <option value="high">🔴 High</option>
                            <option value="medium" selected>🟡 Medium</option>
                            <option value="low">🟢 Low</option>
                        </select>
                        <button id="addBtn">+</button>
                    </div>
                    <div class="floating-list" id="floatingList">
                        <div class="floating-empty">📋 Loading...</div>
                    </div>
                </div>
                <div class="floating-footer">
                    <div class="footer-left">
                        <span>📌</span>
                        <a href="https://github.com/Ashish1731/sticky-notes-extension" target="_blank">Ashish1731</a>
                    </div>
                    <span style="font-size:10px;color:#aaa;">Drag ⠿ to reorder</span>
                    <button class="clear-btn" id="clearBtn">Clear All</button>
                </div>
                <div class="lock-overlay"><span class="lock-badge">🔒 LOCKED</span></div>
            `;

            document.body.appendChild(widgetElement);

            // Pin Icon
            pinIcon = document.createElement('div');
            pinIcon.className = 'floating-pin-icon';
            pinIcon.id = 'floatingPinIcon';
            pinIcon.innerHTML = '📌 <span class="badge pin-badge"></span>';
            pinIcon.style.display = 'none';
            pinIcon.title = 'Click to restore widget';
            document.body.appendChild(pinIcon);

            lockButton = document.getElementById('lockBtn');

            // ===== SETUP EVENT LISTENERS =====
            var slider = document.getElementById('opacitySlider');
            if (slider) {
                slider.addEventListener('input', function (e) {
                    updateOpacity(parseInt(e.target.value));
                });
            }

            var addBtn = document.getElementById('addBtn');
            var noteInput = document.getElementById('noteInput');
            var minimizeBtn = document.getElementById('minimizeBtn');
            var closeBtn = document.getElementById('closeBtn');
            var clearBtn = document.getElementById('clearBtn');
            var lockBtn = document.getElementById('lockBtn');
            var helpBtn = document.getElementById('helpBtn');

            if (addBtn) {
                addBtn.addEventListener('click', function (e) {
                    e.preventDefault();
                    addNote();
                });
            }

            if (noteInput) {
                noteInput.addEventListener('keydown', function (e) {
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        addNote();
                    }
                });
            }

            if (minimizeBtn) minimizeBtn.addEventListener('click', toggleMinimize);
            if (closeBtn) closeBtn.addEventListener('click', closeWidget);
            if (clearBtn) clearBtn.addEventListener('click', clearAll);
            if (lockBtn) lockBtn.addEventListener('click', toggleLock);
            if (helpBtn) helpBtn.addEventListener('click', showHelpTooltip);

            if (pinIcon) {
                pinIcon.addEventListener('click', function (e) {
                    if (!hasDragged && isMinimized) {
                        toggleMinimize();
                    }
                    hasDragged = false;
                });
            }

            // Make draggable
            makeDraggable(widgetElement, false);
            makeDraggable(pinIcon, true);

            // Load saved states
            if (isStorageAvailable()) {
                chrome.storage.local.get(['widgetLocked', 'widgetMinimized', 'widgetVisible', 'widgetClosed', 'widgetPosition', 'widgetOpacity'], function (result) {
                    if (chrome.runtime.lastError) {
                        return;
                    }

                    var posX = 80;
                    var posY = 80;

                    if (result.widgetPosition) {
                        posX = result.widgetPosition.x;
                        posY = result.widgetPosition.y;
                    }

                    widgetElement.style.left = posX + 'px';
                    widgetElement.style.top = posY + 'px';
                    widgetElement.style.right = 'auto';
                    pinIcon.style.left = posX + 'px';
                    pinIcon.style.top = posY + 'px';
                    pinIcon.style.right = 'auto';

                    if (result.widgetMinimized) {
                        isMinimized = true;
                        widgetElement.classList.add('minimized');
                        widgetElement.style.display = 'none';
                        pinIcon.style.display = 'flex';
                    }

                    if (result.widgetClosed) {
                        isClosed = true;
                        isVisible = false;
                        widgetElement.style.display = 'none';
                        pinIcon.style.display = 'none';
                    }

                    if (result.widgetLocked) {
                        isLocked = true;
                        widgetElement.classList.add('locked');
                        if (lockButton) {
                            lockButton.classList.add('locked');
                            lockButton.textContent = '🔒';
                        }
                    }

                    if (result.widgetOpacity !== undefined && result.widgetOpacity !== null) {
                        currentOpacity = result.widgetOpacity;
                        widgetElement.style.opacity = currentOpacity;
                        var value = Math.round(currentOpacity * 100);
                        if (slider) {
                            slider.value = value;
                        }
                        var opacityDisplay = document.getElementById('opacityValue');
                        if (opacityDisplay) {
                            opacityDisplay.textContent = value + '%';
                        }
                    }

                    if (isLocked && !isClosed) {
                        setTimeout(function () {
                            showToast('🔒 Widget locked. Press Ctrl+Shift+L to unlock');
                        }, 500);
                    }
                });
            } else {
                widgetElement.style.left = '80px';
                widgetElement.style.top = '80px';
                widgetElement.style.right = 'auto';
                pinIcon.style.left = '80px';
                pinIcon.style.top = '80px';
                pinIcon.style.right = 'auto';
            }

            loadNotes();

            // Keyboard shortcuts
            document.addEventListener('keydown', function (e) {
                if (e.ctrlKey && e.shiftKey && e.key === 'L') {
                    e.preventDefault();
                    if (isLocked) {
                        setLockState(false);
                    } else {
                        toggleLock();
                    }
                }
                if (e.ctrlKey && e.shiftKey && e.key === 'N') {
                    e.preventDefault();
                    if (isClosed || !isVisible) {
                        showWidget();
                    } else {
                        closeWidget();
                    }
                }
                if (e.ctrlKey && e.shiftKey && e.key === 'M') {
                    e.preventDefault();
                    toggleMinimize();
                }
                if (e.ctrlKey && e.shiftKey && e.key === 'R') {
                    e.preventDefault();
                    resetAllStates();
                }
                if (e.key === '?' && !e.ctrlKey && !e.shiftKey && !e.altKey) {
                    if (document.activeElement && document.activeElement.tagName === 'INPUT') return;
                    e.preventDefault();
                    showHelpTooltip();
                }
            });

            // ===== SAFE MESSAGE LISTENERS =====
            try {
                if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
                    chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
                        if (message.type === 'showWidget') {
                            showWidget();
                            if (sendResponse) sendResponse({ success: true });
                            return true;
                        }
                        if (message.type === 'refreshWidget') {
                            loadNotes();
                            if (sendResponse) sendResponse({ success: true });
                            return true;
                        }
                        if (message.type === 'resetAll') {
                            resetAllStates();
                            if (sendResponse) sendResponse({ success: true });
                            return true;
                        }
                        return false;
                    });
                }
            } catch (e) {
                // Message listener not available - ignore
            }

            // ===== SAFE STORAGE LISTENER =====
            try {
                if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
                    chrome.storage.onChanged.addListener(function (changes, namespace) {
                        if (namespace === 'local' && changes.notes) {
                            notes = changes.notes.newValue || [];
                            sortNotes();
                            renderNotes();
                        }
                    });
                }
            } catch (e) {
                // Storage listener not available - ignore
            }

            console.log('📌 Sticky Notes loaded!');
        });
    }

    // ===== INIT =====
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', createWidget);
    } else {
        setTimeout(createWidget, 100);
    }

})();