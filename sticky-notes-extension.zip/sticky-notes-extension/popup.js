(function () {
    'use strict';

    document.addEventListener('DOMContentLoaded', function () {
        console.log('Popup loaded');

        var statusMsg = document.getElementById('statusMsg');
        var showWidgetBtn = document.getElementById('showWidgetBtn');
        var refreshWidgetBtn = document.getElementById('refreshWidgetBtn');

        if (!showWidgetBtn) {
            console.error('Show Widget button not found');
            return;
        }

        if (!refreshWidgetBtn) {
            console.error('Refresh Widget button not found');
            return;
        }

        // Show Widget Button
        showWidgetBtn.addEventListener('click', function () {
            console.log('Show Widget clicked');

            try {
                chrome.storage.local.set({ widgetVisible: true, widgetClosed: false }, function () {
                    if (chrome.runtime.lastError) {
                        console.error('Storage error:', chrome.runtime.lastError);
                        return;
                    }

                    if (statusMsg) {
                        statusMsg.textContent = '✅ Widget shown';
                        setTimeout(function () {
                            statusMsg.textContent = '✅ Active';
                        }, 2000);
                    }

                    // Send message to all tabs
                    chrome.tabs.query({}, function (tabs) {
                        if (chrome.runtime.lastError) {
                            console.error('Tabs query error:', chrome.runtime.lastError);
                            return;
                        }
                        tabs.forEach(function (tab) {
                            try {
                                chrome.tabs.sendMessage(tab.id, { type: 'showWidget' });
                            } catch (e) {
                                // Tab might not have content script loaded
                            }
                        });
                    });
                });
            } catch (e) {
                console.error('Error:', e);
                if (statusMsg) {
                    statusMsg.textContent = '❌ Error occurred';
                    setTimeout(function () {
                        statusMsg.textContent = '✅ Active';
                    }, 2000);
                }
            }
        });

        // Refresh Widget Button
        refreshWidgetBtn.addEventListener('click', function () {
            console.log('Refresh Widget clicked');

            try {
                chrome.tabs.query({}, function (tabs) {
                    if (chrome.runtime.lastError) {
                        console.error('Tabs query error:', chrome.runtime.lastError);
                        return;
                    }

                    tabs.forEach(function (tab) {
                        try {
                            chrome.tabs.sendMessage(tab.id, { type: 'refreshWidget' });
                        } catch (e) {
                            // Tab might not have content script loaded
                        }
                    });

                    if (statusMsg) {
                        statusMsg.textContent = '✅ Refreshed';
                        setTimeout(function () {
                            statusMsg.textContent = '✅ Active';
                        }, 2000);
                    }
                });
            } catch (e) {
                console.error('Error:', e);
                if (statusMsg) {
                    statusMsg.textContent = '❌ Error occurred';
                    setTimeout(function () {
                        statusMsg.textContent = '✅ Active';
                    }, 2000);
                }
            }
        });
    });

})();