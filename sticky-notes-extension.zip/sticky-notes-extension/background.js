/*
 * Sticky Notes Widget - Background Service Worker
 * Created by Ashish Kumar
 * GitHub: https://github.com/Ashish1731
 */

// ===== INJECT WIDGET ON NAVIGATION =====
chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
    if (changeInfo.status === 'complete' && tab.url && tab.url.startsWith('http')) {
        chrome.storage.local.get(['widgetClosed'], function (result) {
            if (result.widgetClosed !== true) {
                chrome.scripting.executeScript({
                    target: { tabId: tabId },
                    files: ['floating-notes.js']
                }).catch(function () { });
            }
        });
    }
});

// ===== LISTEN FOR MESSAGES =====
chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (message.type === 'showWidget') {
        chrome.storage.local.set({ widgetVisible: true, widgetClosed: false }, function () {
            chrome.tabs.query({}, function (tabs) {
                tabs.forEach(function (tab) {
                    if (tab.url && tab.url.startsWith('http')) {
                        chrome.scripting.executeScript({
                            target: { tabId: tab.id },
                            files: ['floating-notes.js']
                        }).catch(function () { });
                    }
                });
            });
            if (sendResponse) sendResponse({ success: true });
        });
        return true;
    }

    if (message.type === 'refreshWidget') {
        chrome.tabs.query({}, function (tabs) {
            tabs.forEach(function (tab) {
                if (tab.url && tab.url.startsWith('http')) {
                    chrome.scripting.executeScript({
                        target: { tabId: tab.id },
                        files: ['floating-notes.js']
                    }).catch(function () { });
                }
            });
        });
        if (sendResponse) sendResponse({ success: true });
        return true;
    }

    if (message.type === 'resetAll') {
        chrome.storage.local.remove(['widgetLocked', 'widgetMinimized', 'widgetVisible', 'widgetClosed', 'widgetPosition'], function () {
            chrome.tabs.query({}, function (tabs) {
                tabs.forEach(function (tab) {
                    if (tab.url && tab.url.startsWith('http')) {
                        chrome.scripting.executeScript({
                            target: { tabId: tab.id },
                            files: ['floating-notes.js']
                        }).catch(function () { });
                    }
                });
            });
            if (sendResponse) sendResponse({ success: true });
        });
        return true;
    }

    return false;
});

// ===== ON INSTALL =====
chrome.runtime.onInstalled.addListener(function () {
    console.log('📌 Sticky Notes installed!');
    chrome.storage.local.get(['widgetVisible', 'widgetClosed'], function (result) {
        if (result.widgetVisible === undefined && result.widgetClosed === undefined) {
            chrome.storage.local.set({
                widgetVisible: true,
                widgetClosed: false,
                widgetMinimized: false,
                widgetLocked: false
            });
        }
    });
});